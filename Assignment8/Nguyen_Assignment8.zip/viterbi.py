import CPTgen
from math import log

def removeNulls(d):
    #removes 0 probability paths from the dictionary d
    l = []
    for key, val in d.iteritems():
        if val[1] > 0.0:
            l.append(key)
    for elt in l:
        del(d[elt])

states = CPTgen.data.states
f = open('typos20Test.data')
f.readline()
# opening period

times = [{}]
#a list of dictionaries. 
#times[t] gives a dictionary of time (i.e. observation) t that holds
#{a:pointer to parent, b:pointer to parent, c:pointer to parent}
#so something like times[5][a] = the parent of state predicted state
#a at time 5

#time 0, going from dummy to first state
dummytrans = f.readline()[2]
for state in states['dummy'].transitions:
    nextstate = states[state]
    eprob = 0
    try:
        eprob = nextstate.getEmitProb(dummytrans)
        times[0][state] = ('dummy', log(eprob)+log(states['dummy'].getTransProb(state)))
    except:
        times[0][state] = ('dummy', 100.0)
removeNulls(times[0])
curTime = 0
#dict stores the LOG of the belief of that state
for line in f:
    curTime += 1
    times.append({})
    nexttrans = line[2]
    for nextState in states:
        path = (None, -10000.0)
        #this gives emission probability of next state
        try:
            eprob = states[nextState].getEmitProb(nexttrans)
        except:
            eprob = 0
        times[curtime][nextState] = path
        for candPath in times[curTime-1]:
            #LOG of belief of that state
            candprob = times[curTime-1][candPath][1]
            #now we need the probability of transitioning
            #from candidate to nextState
            tprob = 0
            try:
                tprob = states[candPath].getTransProb(nexttrans)
            except:
                tprob = 0
            curBelief = 0 
            try:
                curBelief = log(eprob)+log(tprob)+candprob
            except:
                curBelief = 0
            candidate = (candPath, prob)
            if candidate[1] > times[curTime][nextState][1]:
                times[curTime[nextState]] = candidate
            else:
                continue
            #calculate:
            #P(E|X2)P(X2|X1)B(X1)
            #LOG of that makes:
            #LP(E|X2)+LP(X2|X1)+LB(X1)
            #last value is already stored, no need to take log
